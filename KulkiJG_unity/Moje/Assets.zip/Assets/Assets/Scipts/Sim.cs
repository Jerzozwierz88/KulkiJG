using static UnityEngine.Mathf;
using UnityEngine;
using System.Diagnostics;
using System.IO;
using Unity.Mathematics;
using Unity.VisualScripting;
public class Sim : MonoBehaviour
{
    #region Parametry symulacji
    [Header("Parametry symulacji")]
    public bool running;
    public Vector2[] velocities;
    public Vector2[] positions;
    public float[] densities;
    internal uint NumberOfParticles;
    public uint TotalNumberOfParticles;
    public float radius;
    public float dt;
    public float refreshRate;
    internal Vector2 box_size;
    public float gravity;
    internal const float mass = 1;
    internal const float gamma = 7;
    public float interaction_radius;
    public int evolutionsPerFrame;
    internal uint NumberOfDummies;
    internal float[] dummyDensities;
    private bool settingsNeedUpdate = false;
    #endregion

    #region Parametry SPH
    [Header("SPH parametry")]
    public float targetDensity;
    public float speedOfSound;
    public float viscosity;
    public float artificialViscosityStrength;
    #endregion
    
    #region Compute Shader
    [Header("Compute Shader")]
    public ComputeShader compute;
    public ComputeShader bitonic;
    internal ComputeBuffer posBuffer;
    internal ComputeBuffer velBuffer;
    internal ComputeBuffer densityBuffer;
    internal ComputeBuffer volumeFrBuffer;
    internal ComputeBuffer pressureBuffer;
    internal ComputeBuffer lookupTable;
    internal ComputeBuffer startLookupIndexes;
    internal GPUSort gpuSort;
    ComputeBuffer copyPositions;
    ComputeBuffer f1;
    ComputeBuffer f2;
    ComputeBuffer f3;
    #endregion

    #region Hash
    [Header("Hash")]
    internal uint HashCount;
    internal uint NumXCells;
    internal uint NumYCells;
    internal float2 CellSize;
    #endregion

    #region Kernels
    int posKernel1;
    int forceKernel1;
    int posKernel2;
    int forceKernel2;
    int posKernel3;
    int forceKernel3;
    int densityPartKernel;
    int densityWallKernel;
    int evolutionKernel;
    int runawayKernel;
    int hashKernel;
    public int neighboursTESTkernel;
    int[] posKernels;
    int[] forceKernels;

    int[] RKNkernels;
    #endregion
    private SetupController setup;
    #region Wczytywanie danych

    float[] horVel;
    float[] yVal;
    uint[] counter;
    int socketCount;
    public bool startAveraging = false;
    public bool saveAveraging = false;
    uint save_counter;
    #endregion
    private void Awake()
    {
        running = false;
        setup = GameObject.FindGameObjectWithTag("Setup").GetComponent<SetupController>();
    }
    public void StartSim()
    {
        running = true;
        SetupController spw = setup.GetComponent<SetupController>();

        refreshRate = 1 / (float)Screen.currentResolution.refreshRateRatio.value;

        NumberOfParticles = spw.NumberOfParticles;
        NumberOfDummies = spw.NumberOfDummies;
        positions = spw.positions;
        velocities = spw.velocities;
        radius = spw.radius;
        interaction_radius = spw.interaction_radius;
        box_size = spw.box_size;
        gravity = spw.gravity;
        speedOfSound = spw.speedOfSound;
        targetDensity = spw.targetDensity;
        // targetDensity = NumberOfParticles / (box_size[0] * box_size[1]);
        TotalNumberOfParticles = NumberOfParticles + NumberOfDummies;
        densities = new float[TotalNumberOfParticles];
        for (int i = 0; i < TotalNumberOfParticles; i++) { densities[i] = targetDensity; }

        HashCount = TotalNumberOfParticles + 13;
        NumXCells = (uint)(box_size[0] / interaction_radius);
        NumYCells = (uint)(box_size[1] / interaction_radius);
        CellSize.x = box_size[0] / NumXCells;
        CellSize.y = box_size[1] / NumYCells;

        // Create Compute Buffers
        InitiateComputeShaders();
        UpdateValuesInComputeShaders();

        socketCount = FloorToInt((box_size[1] - 2 * interaction_radius) / (2 * radius));
        horVel = new float[socketCount];
        counter = new uint[socketCount];
        yVal = new float[socketCount];
        for (int i = 0; i < socketCount; i++)
        {
            horVel[i] = 0;
            yVal[i] = ((float)i / socketCount - 0.5f) * (box_size[1] - 2 * interaction_radius);
        }
        DirectoryInfo dir = new DirectoryInfo("HorVEL");
        foreach(FileInfo file in dir.GetFiles())
        {
            file.Delete();
        }
        if (!File.Exists("HorVEL/yVal.txt")) //Checking if scores.txt exists or not
            {
                UnityEngine.Debug.Log("creating file");
                FileStream fs = File.Create("HorVEL/yVal.txt"); //Creates Scores.txt
                fs.Close(); //Closes file stream
            }
        File.WriteAllLines("HorVEL/yVal.txt", System.Array.ConvertAll(yVal, x => x.ToString()));
        save_counter = 0;
    }
    void InitiateComputeShaders()
    {
        #region Set Kernels
        posKernel1 = compute.FindKernel("Pos1");
        forceKernel1 = compute.FindKernel("Force1");

        posKernel2 = compute.FindKernel("Pos2");
        forceKernel2 = compute.FindKernel("Force2");

        posKernel3 = compute.FindKernel("Pos3");
        forceKernel3 = compute.FindKernel("Force3");

        densityPartKernel = compute.FindKernel("DensityParticle");
        densityWallKernel = compute.FindKernel("DensityWall");
        evolutionKernel = compute.FindKernel("Evolution");
        runawayKernel = compute.FindKernel("Runaway");

        neighboursTESTkernel = compute.FindKernel("FindNeighbours");

        int[] importantKernels = { densityPartKernel, densityWallKernel, evolutionKernel, runawayKernel };
        int[] allKernels = { posKernel1, posKernel2, posKernel3, forceKernel1, forceKernel2, forceKernel3, densityPartKernel, densityWallKernel, evolutionKernel, runawayKernel, neighboursTESTkernel };
        posKernels = new int[3] { posKernel1, posKernel2, posKernel3 };
        forceKernels = new int[3] { forceKernel1, forceKernel2, forceKernel3 };
        #endregion

        #region Set Compute Buffers
        posBuffer = new ComputeBuffer((int)TotalNumberOfParticles, sizeof(float) * 2);
        velBuffer = new ComputeBuffer((int)TotalNumberOfParticles, sizeof(float) * 2);
        densityBuffer = new ComputeBuffer((int)TotalNumberOfParticles, sizeof(float));
        volumeFrBuffer = new ComputeBuffer((int)TotalNumberOfParticles, sizeof(float));
        pressureBuffer = new ComputeBuffer((int)TotalNumberOfParticles, sizeof(float));
        gpuSort = new GPUSort();
        startLookupIndexes = new ComputeBuffer((int)HashCount, sizeof(uint));
        lookupTable = new ComputeBuffer((int)TotalNumberOfParticles, 2 * sizeof(uint));
        copyPositions = new ComputeBuffer((int)TotalNumberOfParticles, sizeof(float) * 2);
        gpuSort.SetBuffers(lookupTable, startLookupIndexes);

        f1 = new ComputeBuffer((int)NumberOfParticles, sizeof(float) * 2);
        f2 = new ComputeBuffer((int)NumberOfParticles, sizeof(float) * 2);
        f3 = new ComputeBuffer((int)NumberOfParticles, sizeof(float) * 2);

        posBuffer.SetData(positions);
        velBuffer.SetData(velocities);
        densityBuffer.SetData(densities);

        ComputeHelper.SetBuffer(compute, posBuffer, "positions", allKernels);
        ComputeHelper.SetBuffer(compute, velBuffer, "velocities", allKernels);
        ComputeHelper.SetBuffer(compute, densityBuffer, "densities", allKernels);
        ComputeHelper.SetBuffer(compute, lookupTable, "lookupTable", allKernels);
        ComputeHelper.SetBuffer(compute, startLookupIndexes, "startLookupIndexes", allKernels);
        ComputeHelper.SetBuffer(compute, volumeFrBuffer, "volumeFractions", allKernels);
        ComputeHelper.SetBuffer(compute, pressureBuffer, "pressures", allKernels);

        ComputeHelper.SetBuffer(compute, f1, "f1", allKernels);
        ComputeHelper.SetBuffer(compute, f2, "f2", allKernels);
        ComputeHelper.SetBuffer(compute, f3, "f3", allKernels);
        ComputeHelper.SetBuffer(compute, copyPositions, "copyPositions", allKernels);
        # endregion

        #region Set Parameters
        compute.SetInt("totalNumberOfParticles", (int)TotalNumberOfParticles);
        compute.SetInt("numberOfParticles", (int)NumberOfParticles);
        compute.SetVector("box_size", new Vector4(box_size[0], box_size[1], 0, 0));
        compute.SetFloat("interaction_radius", interaction_radius);
        compute.SetFloat("h", interaction_radius * 0.5f);
        compute.SetFloats("cell_size", new float[2] { CellSize.x, CellSize.y });
        #endregion

        // Set GPU Hashing Compute Shader
        hashKernel = bitonic.FindKernel("Hash");
        bitonic.SetBuffer(hashKernel, "positions", posBuffer);
        bitonic.SetVector("box_size", new Vector4(box_size[0], box_size[1], 0, 0));
        bitonic.SetInt("totalNumberOfParticles", (int)TotalNumberOfParticles);
        bitonic.SetFloat("interaction_radius", interaction_radius);
        bitonic.SetFloats("cell_size", new float[2] { CellSize.x, CellSize.y });

    }
    public void UpdateValuesInComputeShaders()
    {
        compute.SetFloat("mass", mass);
        compute.SetFloat("radius", radius);
        compute.SetFloat("gravity", gravity);
        compute.SetFloat("speedOfSound", speedOfSound);
        compute.SetFloat("artVisStrength", artificialViscosityStrength);
        compute.SetFloat("viscosity", viscosity);
        compute.SetFloat("splineZeroValue", 10 / (7 * PI * interaction_radius * interaction_radius / 4));
        compute.SetFloat("targetDensity", targetDensity);
        compute.SetFloat("referencePressure", targetDensity * speedOfSound * speedOfSound / gamma);
        compute.SetFloat("gamma", gamma);
        compute.SetInt("hashCount", (int)HashCount);
        compute.SetInt("numXCells", (int)NumXCells);
        compute.SetInt("numYCells", (int)NumYCells);
    }
    void OnValidate()
    {
        if (!running) { return; }
        settingsNeedUpdate = true;
    }
    void Update()
    {
        // Update Settings
        if (settingsNeedUpdate) { UpdateValuesInComputeShaders(); }
        // Check if simulation has started
        if (!running) { return; }
        // Display particles
        Stopwatch zegarek = new Stopwatch();
        zegarek.Start();
        posBuffer.GetData(positions);
        velBuffer.GetData(velocities);
        densityBuffer.GetData(densities);
        Vector2 mouse_pos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        compute.SetFloats("mouse_position", new float[2] { mouse_pos[0], mouse_pos[1] });
        GetComponent<Displayer>().Display(positions, radius, NumberOfParticles, NumberOfDummies);
        zegarek.Stop();
        // UnityEngine.Debug.Log("Time to display: " + zegarek.ElapsedMilliseconds);
        // Check if simulation is paused
        if (GetComponent<InputHandler>().paused) { return; }
        // Setup timestep (based on last frame time execution)
        dt = Min(0.125f * interaction_radius / speedOfSound, 0.125f / 4 * interaction_radius * interaction_radius / viscosity, 0.25f * Sqrt(interaction_radius / 2 / Abs(gravity)));
        evolutionsPerFrame = Max(FloorToInt(refreshRate / dt), 1);
        // Skip frame if time step is to large
        if (dt > 0.1) { return; }
        // Perform evolution steps
        zegarek.Restart();
        for (int i = 0; i < evolutionsPerFrame; i++) { UpdateStep(); }
        zegarek.Stop();
        // UnityEngine.Debug.Log("Time to perform evolution steps: " + zegarek.ElapsedMilliseconds);

        // Avereage on sockets
        if (!startAveraging) return;
        for (int i = 0; i < NumberOfParticles; i++)
        {
            int socket = FloorToInt((positions[i].y / (box_size[1]-2*interaction_radius) + 0.5f) * socketCount);
            horVel[socket] = (horVel[socket] * counter[socket] + velocities[i].x) / (counter[socket] + 1);
            counter[socket]++;
        }
        if (saveAveraging)
        {
            string path = $"HorVEL/horVel{save_counter}.txt";
            if (!File.Exists(path)) //Checking if scores.txt exists or not
            {
                UnityEngine.Debug.Log("Tworze plik");
                FileStream fs = File.Create(path);
                fs.Close();
            }
            UnityEngine.Debug.Log("Zapisuje");
            File.WriteAllLines(path, System.Array.ConvertAll(horVel, x => x.ToString()));
            saveAveraging = false;
            startAveraging = false;
            save_counter++;
            for (int i = 0; i < horVel.Length; i++)
            {
                horVel[i] = 0;
                counter[i] = 0;
            }
        }
    }
    private void UpdateStep()
    {
        compute.SetFloat("dt", dt);
        compute.SetBool("dragging", false);
        // Resolve drag
        if (GetComponent<InputHandler>().isDragging)
        {
            float br = GetComponent<InputHandler>().bucket_radius;
            float force_value = GetComponent<InputHandler>().sign * GetComponent<InputHandler>().force_strength * speedOfSound;

            compute.SetBool("dragging", true);
            compute.SetFloat("bucket_radius", br);
            compute.SetFloat("bucket_force", force_value);
        }

        // Get Update Lookup Table - for nearest neighbour search
        gpuSort.CalculateHashes();
        gpuSort.Sort();
        gpuSort.CalculateStartLookupIndexes();
        
        // Perform single RKN4 evolution in steps
        for (int step = 0; step < 3; step++)
        {
            RKN4step(step);
        }
        // ComputeHelper.Dispatch(compute, (int)NumberOfParticles, kernelIndex: densityPartKernel);
        // ComputeHelper.Dispatch(compute, (int)NumberOfDummies, kernelIndex: densityWallKernel);
        ComputeHelper.Dispatch(compute, (int)NumberOfParticles, kernelIndex: evolutionKernel);
        // Fix runaway particles
        ComputeHelper.Dispatch(compute, (int)NumberOfParticles, kernelIndex: runawayKernel);
    }
    void RKN4step(int step)
    {
        ComputeHelper.Dispatch(compute, (int)NumberOfParticles, kernelIndex: posKernels[step]);
        ComputeHelper.Dispatch(compute, (int)NumberOfParticles, kernelIndex: runawayKernel);
        ComputeHelper.Dispatch(compute, (int)NumberOfParticles, kernelIndex: densityPartKernel);
        ComputeHelper.Dispatch(compute, (int)NumberOfDummies, kernelIndex: densityWallKernel);
        ComputeHelper.Dispatch(compute, (int)NumberOfParticles, kernelIndex: forceKernels[step]);
    }
    internal void ReleaseBuffers()
    {
        ComputeHelper.Release(posBuffer, velBuffer, densityBuffer, volumeFrBuffer, pressureBuffer,
         lookupTable, startLookupIndexes, copyPositions, f1, f2, f3, GetComponent<Displayer>().meshBuffer);
    }
    void OnDestroy()
    {
        ReleaseBuffers();
    }
}