using UnityEngine;
using System.Collections.Generic;

public class Displayer : MonoBehaviour
{
    public bool running;
    public Mesh mesh;
    public Material particleMaterial;
    public Material dummyMaterial;
    public Material hashGridMaterial;
    public Material neighbourMaterial;
    private Material material;
    public Shader shader;

    [Header("Buffers")]
    internal ComputeBuffer meshBuffer;
    public ComputeBuffer positionBuffer;
    public ComputeBuffer velocityBuffer;
    public ComputeBuffer densityBuffer;
    private bool needsUpdate = true;
    public Texture2D gradientTexture;
    public Gradient colourMap;
    Bounds bounds;
    public int gradientResolution = 64;
    public float scale;
    public float velocityDisplayMax = 6.4f;
    private uint NumberOfParticles;
    private uint NumberOfDummies;
    private uint TotalNumberOfParticles;
    Sim sim;
    internal ComputeBuffer neighboursTEST;
    int neighboursTESTkernel;

    private void Awake()
    {
        running = false;
    }
    public void SetParameters(SetupController spw)
    {
        NumberOfParticles = spw.NumberOfParticles;
        NumberOfDummies = spw.NumberOfDummies;
        scale = spw.radius * 2;
    }
    public void StartDisp(SetupController spw)
    {
        running = true;
        SetParameters(spw);
        sim = GetComponent<Sim>();
        positionBuffer = sim.posBuffer;
        velocityBuffer = sim.velBuffer;
        densityBuffer = sim.densityBuffer;
        material = new Material(shader);
        material.SetBuffer("Positions2D", positionBuffer);
        material.SetBuffer("Velocities", velocityBuffer);
        material.SetBuffer("Densities", densityBuffer);
        meshBuffer = ComputeHelper.CreateArgsBuffer(mesh, (int)NumberOfParticles);
        bounds = new Bounds(Vector3.zero, Vector3.one * 10000);
        needsUpdate = true;
        UpdateSettings();

        TotalNumberOfParticles = NumberOfDummies + NumberOfParticles;
        neighboursTEST = new ComputeBuffer((int)TotalNumberOfParticles, sizeof(uint));
        neighboursTESTkernel = sim.compute.FindKernel("FindNeighbours");
        ComputeHelper.SetBuffer(sim.compute, neighboursTEST, "neighboursTest", sim.neighboursTESTkernel);
    }

    public void Display(Vector2[] positions, float radius, uint NumberOfParticles, uint NumberOfDummies)
    {
        if (running)
        {
            Graphics.DrawMeshInstancedIndirect(mesh, 0, material, bounds, meshBuffer);
        }
        else
        {
            Matrix4x4[] particleMatrices = new Matrix4x4[NumberOfParticles];
            for (int i = 0; i < NumberOfParticles; i++)
            { particleMatrices[i] = Matrix4x4.TRS(positions[i], Quaternion.identity, Vector3.one * scale); }
            Graphics.DrawMeshInstanced(mesh, 0, particleMaterial, particleMatrices);
        }
        Matrix4x4[] dummyMatrices = new Matrix4x4[NumberOfDummies];
        for (int i = 0; i < NumberOfDummies; i++)
        { dummyMatrices[i] = Matrix4x4.TRS(positions[i + NumberOfParticles], Quaternion.identity, Vector3.one * scale); }
        Graphics.DrawMeshInstanced(mesh, 0, dummyMaterial, dummyMatrices);

        if (running && GetComponent<InputHandler>().paused)
        {
            ResolvePause();
        }
    }

    public void ResolvePause()
    {
        Matrix4x4[] gridMatrixes = new Matrix4x4[sim.NumXCells * sim.NumYCells];
        int i = 0;
        for (int xNum = 0; xNum < sim.NumXCells; xNum++)
        {
            for (int yNum = 0; yNum < sim.NumYCells; yNum++)
            {
                float xcoord = -sim.box_size[0] / 2 + (xNum + 0.5f) * sim.CellSize.x;
                float ycoord = -sim.box_size[1] / 2 + (yNum + 0.5f) * sim.CellSize.y;
                gridMatrixes[i] = Matrix4x4.TRS(new Vector2(xcoord, ycoord), Quaternion.identity, new Vector3(sim.CellSize.x, sim.CellSize.y, 1));
                i++;
            }
        }
        Graphics.DrawMeshInstanced(mesh, 0, hashGridMaterial, gridMatrixes);

        if (Input.GetMouseButton(0))
        {
            ComputeHelper.Dispatch(sim.compute, 1, kernelIndex: sim.neighboursTESTkernel);
            uint[] nIDX = new uint[TotalNumberOfParticles];
            neighboursTEST.GetData(nIDX);
            List<Matrix4x4> neighboursMatrixes = new List<Matrix4x4>();
            foreach (uint idx in nIDX)
            {
                if (idx == TotalNumberOfParticles) break;
                neighboursMatrixes.Add(Matrix4x4.TRS(sim.positions[idx], Quaternion.identity, Vector2.one * sim.radius * 2.5f));
            }
            Graphics.DrawMeshInstanced(mesh, 0, neighbourMaterial, neighboursMatrixes);
        }
    }


    void LateUpdate()
    {
        if (running && shader != null)
        {
            UpdateSettings();
        }
    }

    void UpdateSettings()
    {
        if (needsUpdate)
        {
            needsUpdate = false;
            TextureFromGradient(ref gradientTexture, gradientResolution, colourMap);
            material.SetTexture("ColourMap", gradientTexture);
            material.SetFloat("scale", scale);
            material.SetFloat("velocityMax", velocityDisplayMax);
            material.SetFloat("targetDensity", GetComponent<Sim>().targetDensity);
        }
    }

    public static void TextureFromGradient(ref Texture2D texture, int width, Gradient gradient, FilterMode filterMode = FilterMode.Bilinear)
    {
        if (texture == null)
        {
            texture = new Texture2D(width, 1);
        }
        else if (texture.width != width)
        {
            texture.Reinitialize(width, 1);
        }
        if (gradient == null)
        {
            gradient = new Gradient();
            gradient.SetKeys(
                new GradientColorKey[] { new GradientColorKey(Color.black, 0), new GradientColorKey(Color.black, 1) },
                new GradientAlphaKey[] { new GradientAlphaKey(1, 0), new GradientAlphaKey(1, 1) }
            );
        }
        texture.wrapMode = TextureWrapMode.Clamp;
        texture.filterMode = filterMode;

        Color[] cols = new Color[width];
        for (int i = 0; i < cols.Length; i++)
        {
            float t = i / (cols.Length - 1f);
            cols[i] = gradient.Evaluate(t);
        }
        texture.SetPixels(cols);
        texture.Apply();
    }

    void OnValidate()
    {
        needsUpdate = true;
    }
}
