using UnityEngine;
using UnityEngine.UIElements;

public class UIController : MonoBehaviour
{
    private VisualElement ui;
    private Sim sim;
    private GameObject setup;

    private Button playOn;
    private Button reset;
    private Slider gravity;
    private Slider density;
    Slider speedOfSound;
    Slider viscosity;
    Button quit;

    private void Awake()
    {
        sim = GameObject.FindGameObjectWithTag("Sim").GetComponent<Sim>();
        setup = GameObject.FindGameObjectWithTag("Setup");
    }


    private void Start()
    {
        gameObject.SetActive(false);
    }

    private void OnEnable()
    {
        ui = GetComponent<UIDocument>().rootVisualElement;

        playOn = ui.Q<Button>("PlayOn");
        reset = ui.Q<Button>("Reset");
        gravity = ui.Q<Slider>("Gravity");
        density = ui.Q<Slider>("Density");
        speedOfSound = ui.Q<Slider>("SpeedOfSound");
        viscosity = ui.Q<Slider>("Viscosity");
        quit = ui.Q<Button>("Quit");
        playOn.RegisterCallback<MouseUpEvent>(OnPlayOnClick);
        reset.RegisterCallback<MouseUpEvent>(OnResetClick);
        quit.RegisterCallback<MouseUpEvent>((evt) =>
        {
            Application.Quit();
            Debug.Log("Closing the game");
        });
        gravity.RegisterCallback<ChangeEvent<float>>(ChangeGravity);
        gravity.value = Mathf.Abs(sim.gravity);
        density.RegisterCallback<ChangeEvent<float>>(ChangeDensity);
        density.value = Mathf.Sqrt(sim.targetDensity);

        speedOfSound.RegisterCallback<ChangeEvent<float>>((evt) =>
        {
            sim.speedOfSound = evt.newValue;
        });
        speedOfSound.value = sim.speedOfSound;

        viscosity.RegisterCallback<ChangeEvent<float>>((evt) =>
        {
            sim.viscosity = evt.newValue;
        });
        viscosity.value = sim.viscosity;
    }
    private void OnDisable()
    {
        playOn.UnregisterCallback<MouseUpEvent>(OnPlayOnClick);
        reset.UnregisterCallback<MouseUpEvent>(OnResetClick);
    }
            
    private void OnPlayOnClick(MouseUpEvent evt)
    {
        sim.UpdateValuesInComputeShaders();
        gameObject.SetActive(false);
    }
    private void OnResetClick(MouseUpEvent evt)
    {
        sim.GetComponent<InputHandler>().running = false;
        sim.running = false;
        sim.GetComponent<Displayer>().running = false;
        sim.ReleaseBuffers();
        setup.SetActive(true);
        gameObject.SetActive(false);
    }

    private void ChangeGravity(ChangeEvent<float> evt)
    {
        Debug.Log("Changed gravity");
        sim.gravity = -evt.newValue;
    }

    private void ChangeDensity(ChangeEvent<float> evt)
    {
        Debug.Log("Changed density");
        sim.targetDensity = evt.newValue*evt.newValue;
    }
}
